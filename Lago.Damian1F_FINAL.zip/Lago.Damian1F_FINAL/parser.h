#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "ArrayList.h"

int parser(char* fileName, ArrayList* lista);

int generarArchivo(char* fileName,ArrayList* lista);
#endif // PARSER_H_INCLUDED

